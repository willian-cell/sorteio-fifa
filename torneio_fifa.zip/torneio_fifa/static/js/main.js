// ======== Dicionário de Times ========
const timesPorLiga = {
    "Brasil": ["Flamengo", "Palmeiras", "São Paulo", "Corinthians", "Grêmio", "Atlético-MG", "Internacional", "Fluminense", "Botafogo", "Cruzeiro"],
    "Inglaterra": ["Manchester City", "Liverpool", "Arsenal", "Chelsea", "Manchester United", "Tottenham", "Newcastle", "Aston Villa", "West Ham", "Brighton"],
    "Espanha": ["Real Madrid", "Barcelona", "Atlético de Madrid", "Sevilla", "Real Sociedad", "Villarreal", "Valencia", "Athletic Bilbao", "Real Betis", "Celta de Vigo"],
    "Alemanha": ["Bayern de Munique", "Borussia Dortmund", "RB Leipzig", "Bayer Leverkusen", "Eintracht Frankfurt", "Union Berlin", "Wolfsburg", "Freiburg", "Mainz", "Stuttgart"],
    "Itália": ["Juventus", "Inter de Milão", "Milan", "Napoli", "Roma", "Lazio", "Fiorentina", "Atalanta", "Torino", "Sassuolo"],
    "França": ["Paris Saint-Germain", "Olympique de Marseille", "Lyon", "Monaco", "Lille", "Nice", "Rennes", "Strasbourg", "Nantes", "Toulouse"],
    "Portugal": ["Benfica", "Porto", "Sporting CP", "Braga", "Vitória de Guimarães", "Boavista", "Marítimo", "Rio Ave", "Famalicão", "Casa Pia"],
    "Holanda": ["Ajax", "PSV", "Feyenoord", "AZ Alkmaar", "Twente", "Heerenveen", "Utrecht", "Sparta Rotterdam", "NEC", "Go Ahead Eagles"],
    "Argentina": ["Boca Juniors", "River Plate", "Racing Club", "Independiente", "San Lorenzo", "Vélez Sarsfield", "Estudiantes", "Lanús", "Rosario Central", "Argentinos Juniors"],
    "Outros": ["Galatasaray", "Besiktas", "Fenerbahçe", "Celtic", "Rangers", "Shakhtar Donetsk", "Dinamo Zagreb", "Al Nassr", "Al Hilal", "MLS All-Stars"]
  };
  
  // ======== Utilitários ========
  function mostrarSecao(secaoId) {
    document.querySelectorAll("main > div").forEach(div => div.classList.add("hidden"));
    document.getElementById(secaoId).classList.remove("hidden");
  }
  
  
  function criarTabela(titulos, dados) {
    const thead = `<thead><tr>${titulos.map(t => `<th>${t}</th>`).join('')}</tr></thead>`;
    const tbody = `<tbody>${dados.map(linha => `<tr>${linha.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>`;
    return `<table class="resultado-tabela">${thead}${tbody}</table>`;
  }
  
  // ======== Cadastro de Jogador ========
  document.getElementById('formCadastro').addEventListener('submit', async (event) => {
    event.preventDefault();
    const nome = document.getElementById('nome').value.trim();
    if (!nome) return alert("Digite um nome válido!");
  
    const response = await fetch('/cadastrar_jogador', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome })
    });
  
    const data = await response.json();
    alert(data.message);
    event.target.reset();
  
    // Adiciona o nome na lista dinâmica
    const lista = document.getElementById('listaCadastro');
    const item = document.createElement('li');
    item.textContent = nome;
    item.classList.add('list-group-item');
    lista.appendChild(item);
  });
  
  // Carrega jogadores já cadastrados ao iniciar
window.addEventListener('DOMContentLoaded', async () => {
  const res = await fetch('/ver_banco');
  const data = await res.json();

  const lista = document.getElementById('listaCadastro');
  lista.innerHTML = ''; // limpa caso já exista algo

  data.jogadores.forEach(jogador => {
    const item = document.createElement('li');
    item.textContent = jogador.nome;
    item.classList.add('list-group-item');
    lista.appendChild(item);
  });
});

  
async function sortearOrdemEscolha() {
  const resultadoDiv = document.getElementById('resultado-ordem');
  resultadoDiv.innerHTML = `
    <div class="alert alert-info" role="alert">
      ⏳ Realizando sorteio, aguarde...
    </div>
  `;

  // 1. Verifica se há jogadores no banco
  const verRes = await fetch('/ver_banco');
  const verData = await verRes.json();

  if (!verData.jogadores || verData.jogadores.length === 0) {
    alert("Nenhum jogador cadastrado! Redirecionando para a tela de cadastro...");
    mostrarSecao('cadastrar');
    return;
  }

  // 2. Continua com o sorteio
  const res = await fetch('/sortear_ordem_escolha', { method: 'POST' });
  const data = await res.json();
  const jogadores = Object.entries(data.ordem_escolha);

  // Junta todos os times em uma lista única
  let todosTimes = [];
  Object.values(timesPorLiga).forEach(lista => {
    todosTimes = todosTimes.concat(lista);
  });

  if (jogadores.length > todosTimes.length) {
    resultadoDiv.innerHTML = `<div class="alert alert-warning">⚠️ Jogadores excedem o número de times disponíveis.</div>`;
    return;
  }

  const timesDisponiveis = [...todosTimes];

  const associacoes = jogadores.map(([nome, ordem]) => {
    const time = timesDisponiveis.splice(Math.floor(Math.random() * timesDisponiveis.length), 1)[0];
    fetch('/escolher_time', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, time })
    });
    return { nome, ordem, time };
  });

  // Ordenar por ordem de sorteio
  associacoes.sort((a, b) => a.ordem - b.ordem);

  // Criar tabela estilizada
  const linhas = associacoes.map(j => [
    `<strong>${j.nome}</strong>`,
    `<span class="badge bg-primary">${j.ordem}</span>`,
    `<span contenteditable="true" class="editable-time text-success fw-semibold" data-nome="${j.nome}">${j.time}</span>`
  ]);

  const tabelaHTML = criarTabela(["👤 Nome", "🎯 Ordem", "🏟️ Time"], linhas);
  resultadoDiv.innerHTML = `
    <div class="card border-0 shadow-sm animate__animated animate__fadeIn">
      <div class="card-body">
        <h4 class="card-title mb-4">📋 Resultado do Sorteio</h4>
        ${tabelaHTML}
        <p class="text-muted mt-2">📝 Clique no nome do time para editar, se desejar.</p>
      </div>
    </div>
  `;

  // Ativa edição inline
  document.querySelectorAll('.editable-time').forEach(span => {
    span.addEventListener('blur', async (event) => {
      const novoTime = event.target.textContent.trim();
      const nomeJogador = event.target.dataset.nome;

      if (!novoTime) {
        alert("O nome do time não pode ficar vazio.");
        event.target.textContent = "Time Inválido";
        return;
      }

      const res = await fetch('/escolher_time', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome: nomeJogador, time: novoTime })
      });

      const data = await res.json();
      alert(data.message);
    });
  });
}



  
  // ======== Escolher Time Manual ========
  document.getElementById('formEscolherTime').addEventListener('submit', async (event) => {
    event.preventDefault();
    const nome = document.getElementById('nomeEscolha').value.trim();
    const time = document.getElementById('timeEscolha').value.trim();
    if (!nome || !time) return alert("Preencha ambos os campos.");
  
    const res = await fetch('/escolher_time', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, time })
    });
    const data = await res.json();
    alert(data.message);
    event.target.reset();
  });
  
  // ======== Sortear Confrontos ========
async function sortearTorneio() {
  const resultadoDiv = document.getElementById('resultado');

  // Mensagem de carregamento
  resultadoDiv.innerHTML = `
    <div class="alert alert-info" role="alert">
      ⏳ Realizando sorteio dos confrontos, por favor aguarde...
    </div>
  `;

  try {
    // Requisição ao backend
    const res = await fetch('/sortear_torneio', { method: 'POST' });
    const data = await res.json();

    if (!data.confrontos || data.confrontos.length === 0) {
      resultadoDiv.innerHTML = `
        <div class="alert alert-warning" role="alert">
          ⚠️ Nenhum confronto foi sorteado. Verifique se há jogadores suficientes.
        </div>
      `;
      return;
    }

    alert(`✅ ${data.message}`);

    // Criação da tabela de confrontos
    const linhas = data.confrontos.map((c, i) => [
      `<div class="text-start"><strong class="text-primary">🏠 ${c[0].nome}</strong><br><small class="text-muted">${c[0].time}</small></div>`,
      `<span class="badge bg-secondary fs-6">Jogo ${i + 1}</span>`,
      `<div class="text-end"><strong class="text-danger">🚩 ${c[1].nome}</strong><br><small class="text-muted">${c[1].time}</small></div>`
    ]);

    const tabelaHTML = criarTabela(["Casa", "🆚", "Visitante"], linhas);

    resultadoDiv.innerHTML = `
      <div class="card border-0 shadow-sm animate__animated animate__fadeIn">
        <div class="card-body">
          <h4 class="card-title text-center mb-4 text-success">🎯 ${data.confrontos.length} Confrontos Definidos</h4>
          ${tabelaHTML}
          <p class="text-muted text-center mt-3">✅ Sorteio concluído. Os confrontos estão prontos para registro dos vencedores.</p>
        </div>
      </div>
    `;
  } catch (error) {
    console.error("Erro ao sortear confrontos:", error);
    resultadoDiv.innerHTML = `
      <div class="alert alert-danger" role="alert">
        ❌ Ocorreu um erro ao realizar o sorteio. Tente novamente.
      </div>
    `;
  }
}


  async function verBanco() {
    const res = await fetch('/ver_banco');
    const data = await res.json();
  
    if (!data.jogadores.length) {
      document.getElementById('lista-banco').innerHTML = "<p class='text-muted'>Nenhum jogador cadastrado.</p>";
      return;
    }
  
    const listaHTML = data.jogadores.map(j => `<li><strong>${j.nome}</strong> - ${j.time || "Sem time"} (Ordem: ${j.ordem || "-"})</li>`).join('');
    document.getElementById('lista-banco').innerHTML = `<h4>Jogadores Cadastrados</h4><ul class="list-group list-group-flush">${listaHTML}</ul>`;
  }

  

  async function limparBanco() {
    if (confirm("Tem certeza que deseja apagar todos os dados do banco de dados?")) {
      const res = await fetch('/limpar_banco', { method: 'POST' });
      const data = await res.json();
      alert(data.message);
      location.reload(); // Recarrega a página após limpeza
    }
  }
  


  let faseAtual = 1;
  let fases = [];
  
  async function iniciarChaveamento() {
    const res = await fetch('/gerar_chaveamento', { method: 'POST' });
    const data = await res.json();
    fases.push(data.confrontos);
    renderFase(data.confrontos, faseAtual);
  }
  
  function renderFase(confrontos, faseNum) {
    const chaveDiv = document.getElementById("chaveamento-torneio");
    const faseDiv = document.createElement("div");
    faseDiv.className = "fase";
    faseDiv.innerHTML = `<h3>Fase ${faseNum}</h3>`;
  
    confrontos.forEach((jogo, idx) => {
      const box = document.createElement("div");
      box.className = "confronto";
      box.innerHTML = `
        <button class="btn-jogador" onclick="escolherVencedor('${jogo.casa}')">${jogo.casa}</button>
        <span>vs</span>
        <button class="btn-jogador" onclick="escolherVencedor('${jogo.visitante}')">${jogo.visitante}</button>
      `;
      faseDiv.appendChild(box);
    });
  
    chaveDiv.appendChild(faseDiv);
  }
  
  async function escolherVencedor(nome) {
    const res = await fetch('/registrar_vencedor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ vencedor: nome })
    });
  
    const data = await res.json();
    const fasesData = data.fases;
    const novaFaseKey = `fase_${faseAtual + 1}`;
  
    if (data.campeao) {
      document.getElementById("campeao").innerText = `🏅 Campeão: ${data.campeao}`;
      return;
    }
  
    if (fasesData[novaFaseKey]) {
      faseAtual++;
      fases.push(fasesData[novaFaseKey]);
      renderFase(fasesData[novaFaseKey], faseAtual);
    }
  }
  