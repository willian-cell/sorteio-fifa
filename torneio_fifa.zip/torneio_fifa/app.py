# app.py
import os
import openpyxl
from flask import Flask, render_template, request, jsonify, url_for,session, jsonify
import random
import sqlite3
import random
import webbrowser
import threading

app = Flask(__name__)

EXCEL_PATH = 'torneio.xlsx'
DB_PATH = 'jogadores.db'

def abrir_navegador():
    webbrowser.open_new('http://127.0.0.1:5000')

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS jogadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                time TEXT,
                ordem_escolha INTEGER
            )
        ''')
        conn.commit()

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/cadastrar_jogador', methods=['POST'])
def cadastrar_jogador():
    data = request.json
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO jogadores (nome, time, ordem_escolha)
                VALUES (?, ?, ?)
            ''', (data['nome'], data.get('time'), data.get('ordem_escolha')))
            conn.commit()
        return jsonify({'message': 'Jogador cadastrado com sucesso!'})
    except Exception as e:
        return jsonify({'message': f'Erro: {str(e)}'}), 500

@app.route('/sortear_ordem_escolha', methods=['POST'])
def sortear_ordem_escolha():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT nome FROM jogadores')
        jogadores = cursor.fetchall()

    if len(jogadores) % 2 != 0:
        return jsonify({'message': 'Número de jogadores deve ser par.'}), 400

    random.shuffle(jogadores)
    ordem_escolha = {jogador[0]: idx + 1 for idx, jogador in enumerate(jogadores)}

    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        for nome, ordem in ordem_escolha.items():
            cursor.execute('''
                UPDATE jogadores
                SET ordem_escolha = ?
                WHERE nome = ?
            ''', (ordem, nome))
        conn.commit()

    return jsonify({'message': 'Ordem de escolha sorteada com sucesso!', 'ordem_escolha': ordem_escolha})

@app.route('/escolher_time', methods=['POST'])
def escolher_time():
    data = request.json
    nome = data['nome']
    time = data['time']

    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE jogadores
            SET time = ?
            WHERE nome = ?
        ''', (time, nome))
        conn.commit()

    return jsonify({'message': f'Time {time} escolhido por {nome} com sucesso!'})

@app.route('/sortear_torneio', methods=['POST'])
def sortear_torneio():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT nome, time FROM jogadores WHERE ordem_escolha IS NOT NULL AND time IS NOT NULL ORDER BY ordem_escolha')
        jogadores = cursor.fetchall()

    if len(jogadores) % 2 != 0:
        return jsonify({'message': 'Número de jogadores deve ser par.'}), 400

    chave_a = jogadores[:len(jogadores)//2]
    chave_b = jogadores[len(jogadores)//2:]

    confrontos = []
    for i in range(len(chave_a)):
        confrontos.append([
            {'nome': chave_a[i][0], 'time': chave_a[i][1]},
            {'nome': chave_b[i][0], 'time': chave_b[i][1]}
        ])

    gerar_excel(confrontos)
    return jsonify({'message': 'Torneio sorteado com sucesso!', 'confrontos': confrontos})

def gerar_excel(confrontos):
    workbook = openpyxl.Workbook() if not os.path.exists(EXCEL_PATH) else openpyxl.load_workbook(EXCEL_PATH)
    sheet = workbook.active

    if sheet.max_row == 1:
        sheet.append(['Jogador 1', 'Jogador 2'])

    for confronto in confrontos:
        sheet.append([confronto[0]['nome'], confronto[1]['nome']])

    workbook.save(EXCEL_PATH)





@app.route('/gerar_chaveamento', methods=['POST'])
def gerar_chaveamento():
    conn = DB_PATH()
    cursor = conn.cursor()

    cursor.execute("SELECT nome FROM jogadores ORDER BY ordem")
    jogadores = [row[0] for row in cursor.fetchall()]
    conn.close()

    if len(jogadores) % 2 != 0:
        return jsonify({"erro": "Número ímpar de jogadores. Insira um número par para o chaveamento."}), 400

    random.shuffle(jogadores)

    confrontos = []
    for i in range(0, len(jogadores), 2):
        confrontos.append({
            "casa": jogadores[i],
            "visitante": jogadores[i+1],
            "vencedor": None
        })

    session['fases'] = {"fase_1": confrontos}
    session['campeao'] = None
    return jsonify({"fase": "fase_1", "confrontos": confrontos})



@app.route('/ver_chaveamento')
def ver_chaveamento():
    return jsonify({
        "fases": session.get("fases", {}),
        "campeao": session.get("campeao", None)
    })



@app.route('/avancar_fase', methods=['POST'])
def avancar_fase():
    fases = session.get("fases", {})
    fase_atual = sorted(fases.keys())[-1]

    vencedores = [c['vencedor'] for c in fases[fase_atual] if c['vencedor']]
    if len(vencedores) < len(fases[fase_atual]):
        return jsonify({"erro": "Ainda há confrontos sem vencedores definidos."}), 400

    if len(vencedores) == 1:
        session['campeao'] = vencedores[0]
        return jsonify({"campeao": vencedores[0]})

    nova_fase = f"fase_{len(fases) + 1}"
    novos_confrontos = []
    for i in range(0, len(vencedores), 2):
        novos_confrontos.append({
            "casa": vencedores[i],
            "visitante": vencedores[i+1],
            "vencedor": None
        })

    fases[nova_fase] = novos_confrontos
    session["fases"] = fases
    return jsonify({"fase": nova_fase, "confrontos": novos_confrontos})




@app.route('/registrar_vencedor', methods=['POST'])
def registrar_vencedor():
    data = request.json
    nome_vencedor = data['vencedor']

    fases = session.get('fases', {})
    fase_atual = sorted(fases.keys())[-1]

    # Marca o vencedor no confronto atual
    for c in fases[fase_atual]:
        if c['casa'] == nome_vencedor or c['visitante'] == nome_vencedor:
            c['vencedor'] = nome_vencedor
            break

    # Verifica se todos os vencedores estão definidos
    vencedores = [c['vencedor'] for c in fases[fase_atual] if c['vencedor']]
    if len(vencedores) == len(fases[fase_atual]):
        if len(vencedores) == 1:
            session['campeao'] = vencedores[0]
        else:
            nova_fase = f"fase_{len(fases) + 1}"
            novos_confrontos = []
            for i in range(0, len(vencedores), 2):
                novos_confrontos.append({
                    "casa": vencedores[i],
                    "visitante": vencedores[i+1],
                    "vencedor": None
                })
            fases[nova_fase] = novos_confrontos

    session['fases'] = fases
    return jsonify({"fases": fases, "campeao": session.get("campeao")})



@app.route('/ver_banco')
def ver_banco():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT nome, time, ordem_escolha FROM jogadores ORDER BY nome ASC')
            jogadores = cursor.fetchall()
        lista = [{'nome': j[0], 'time': j[1], 'ordem': j[2]} for j in jogadores]
        return jsonify({'jogadores': lista})
    except Exception as e:
        return jsonify({'message': f'Erro ao consultar banco: {str(e)}'}), 500




@app.route('/limpar_banco', methods=['POST'])
def limpar_banco():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM jogadores')
            conn.commit()
        return jsonify({'message': 'Banco de dados limpo com sucesso!'})
    except Exception as e:
        return jsonify({'message': f'Erro ao limpar banco: {str(e)}'}), 500


if __name__ == '__main__':
    init_db()
    threading.Timer(1.5, abrir_navegador).start()
    app.run(debug=True)